from django.apps import AppConfig


class TweetAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tweet'
